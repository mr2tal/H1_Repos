use master
go

if exists (select * from sys.databases where name = 'FilmDB')
begin
	print ('databasen findes allerede, og derfor droppes')
	drop database FilmDB
end
go

create database FilmDB on
primary
	(name=N'FilmDB' , filename = 'C:\Eksamen\FilmDB.mdf' , size = 8MB, maxsize = unlimited, filegrowth = 64MB),
filegroup fg1
	(name=N'Genre_Fg' , filename = 'C:\Eksamen\Genre_Fg.ndf' , size = 8MB, maxsize = unlimited, filegrowth = 64MB), 
filegroup fg2
	(name=N'Film_Fg' , filename = 'C:\Eksamen\Film_Fg.ndf' , size = 8MB, maxsize = unlimited, filegrowth = 64MB),
filegroup fg3
	(name=N'Skuespiller_Fg' , filename = 'C:\Eksamen\Skuespiller_Fg.ndf' , size = 8MB, maxsize = unlimited, filegrowth = 64MB),
filegroup fg4
	(name=N'FilmSkuespiller_Fg' , filename = 'C:\Eksamen\FilmSkuespiller_Fg.ndf' , size = 8MB, maxsize = unlimited, filegrowth = 64MB)
go

use FilmDB 
go

create table Genre	(
					GenreID int primary key identity (1,1),
					GenreNavn nvarchar(30),
					Beskrivelse nvarchar(70)
					)
on fg1

create table Film	(
					FilmID int primary key identity (1,1),
					Titel nvarchar(40),
					Instruktoer nvarchar(40),
					Spilletid int,
					check (Spilletid < 180),
					Dato date,
					GenreID int foreign key references Genre(GenreID) not null
					)
on fg2

create table Skuespiller	(
					SkuespillerID int primary key identity (1,1),
					Navn nvarchar (70) not null,
					Portr�t nvarchar (70)
							)
on fg3

create table FilmSkuespiller	(
					FilmID int foreign key references Film(FilmID),
					SkuespillerID int foreign key references Skuespiller(SkuespillerID)
								)
on fg4
go

create trigger NyFilmTrigger on Film for insert
as
begin
declare @Film nvarchar (50)
select @Film = i.Titel from inserted i
print 'Filmen ' + @Film + ' Er blevet tilf�jet'
end
go

create index Index_Film on Film(Titel)
create index Index_Genre on Genre(GenreNavn)
create index Index_Skuespiller on Skuespiller(Navn)

backup database FilmDB
to Disk = 'C:\Eksamen\BackupFilmDB.bak'
with init, stop_on_error, compression,
name = 'BackupFilmDB',
description = 'Backup af vores film database'

Backup database FilmDB
to Disk = 'C:\Eksamen\BackupFilmDB.dif'
with differential, compression, init, stop_on_error
